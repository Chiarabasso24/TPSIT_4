
package corsa.java;

/**
 * Corsa contiene il man
 * @author Andrea Vallorani
 */
public class Corsa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Pista p = new Pista();
        p.setVisible(true);
    }
    
}
